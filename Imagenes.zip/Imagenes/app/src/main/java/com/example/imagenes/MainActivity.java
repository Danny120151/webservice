package com.example.imagenes;

import androidx.annotation.IntRange;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import com.google.android.material.textfield.TextInputLayout;
import com.kc.unsplash.Unsplash;
import com.kc.unsplash.*;
import com.kc.unsplash.models.Photo;
import com.kc.unsplash.Unsplash;

import com.kc.unsplash.api.Order;


import com.kc.unsplash.models.Photo;


import com.kc.unsplash.models.SearchResults;
import com.squareup.picasso.Picasso;


import org.w3c.dom.Text;

import java.util.List;


public class MainActivity extends AppCompatActivity {

    Button btnbuscar;
    ImageView imgfonfondo;
    EditText  editText;
   private Unsplash unsplash = new Unsplash("0RgZCB0GDB6ZxdUHYJittwp2VW9Fa0pVctVJqfhjLuY");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnbuscar = (Button) findViewById(R.id.btnbuscar);
        imgfonfondo = (ImageView) findViewById(R.id.imgfonfondo);
        editText= findViewById(R.id.editText);
        btnbuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editText != null){

                    Log.d("textobuscar:",editText.getText().toString());

                    search(editText.getText().toString());

                }
            }
        });
    }
    public void search(String query){
       // EditText editText = findViewById(R.id.editText);
      // String query = editText.getText().toString();

        unsplash.searchPhotos(query, new Unsplash.OnSearchCompleteListener() {

            @Override

            public void onComplete(SearchResults results) {
                Log.d("Photos", "Total Results Found " + results.getTotal());
                List<Photo> photos = results.getResults();
                    //imgfonfondo.setPhotos(photos);
                String photoUrl = photos.get(1).getUrls().getRegular();
                Picasso.get().load(photoUrl).into(imgfonfondo);
                photos.clear();



            }

                   //adapter.setPhotos(photos);

            @Override

            public void onError(String error) {
                Log.d("Unsplash", error);
            }

        });
    }
}
